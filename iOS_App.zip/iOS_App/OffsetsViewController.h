//
//  OffsetsViewController.h
//  DOX O KDA
//

#import <UIKit/UIKit.h>

@interface OffsetsViewController : UIViewController

@end
