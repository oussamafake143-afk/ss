//
//  KeysViewController.m
//  DOX KDA
//

#import "KeysViewController.h"
#import "APIManager.h"

@interface KeysViewController () <UITableViewDelegate, UITableViewDataSource>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSArray *keys;
@end

@implementation KeysViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor colorWithRed:0.05 green:0.05 blue:0.05 alpha:1.0];
    self.title = @"Keys";
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(generateKey)];
    
    [self setupTableView];
    [self loadKeys];
}

- (void)setupTableView {
    self.tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.backgroundColor = [UIColor colorWithRed:0.05 green:0.05 blue:0.05 alpha:1.0];
    self.tableView.separatorColor = [UIColor colorWithWhite:0.2 alpha:1.0];
    self.tableView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [self.view addSubview:self.tableView];
    
    UIRefreshControl *refreshControl = [[UIRefreshControl alloc] init];
    [refreshControl addTarget:self action:@selector(loadKeys) forControlEvents:UIControlEventValueChanged];
    self.tableView.refreshControl = refreshControl;
}

- (void)loadKeys {
    [[APIManager sharedManager] getKeysWithSuccess:^(NSDictionary *response) {
        [self.tableView.refreshControl endRefreshing];
        
        if (response[@"keys"]) {
            self.keys = response[@"keys"];
            NSLog(@"✅ Loaded %lu keys", (unsigned long)self.keys.count);
        } else {
            self.keys = @[];
            NSLog(@"⚠️ No keys in response");
        }
        
        [self.tableView reloadData];
    } failure:^(NSError *error) {
        [self.tableView.refreshControl endRefreshing];
        NSString *errorMsg = [NSString stringWithFormat:@"Failed to load keys: %@", error.localizedDescription];
        NSLog(@"❌ Error loading keys: %@", error);
        [self showAlert:@"Error" message:errorMsg];
    }];
}

- (void)generateKey {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Generate Key" message:@"Enter key details" preferredStyle:UIAlertControllerStyleAlert];
    
    [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.placeholder = @"Package Name";
    }];
    
    [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.placeholder = @"Duration (days)";
        textField.keyboardType = UIKeyboardTypeNumberPad;
        textField.text = @"30";
    }];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:@"Generate" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        NSString *packageName = alert.textFields[0].text;
        NSString *duration = alert.textFields[1].text;
        
        if (packageName.length > 0) {
            NSLog(@"🔑 Generating key for package: %@", packageName);
            
            NSDictionary *data = @{
                @"package_name": packageName,
                @"duration_days": @([duration integerValue] ?: 30),
                @"status": @"active"
            };
            
            [[APIManager sharedManager] createKeyWithData:data success:^(NSDictionary *response) {
                NSLog(@"✅ Key generated: %@", response);
                [self loadKeys];
                
                if (response[@"key"]) {
                    NSDictionary *key = response[@"key"];
                    NSString *successMsg = [NSString stringWithFormat:@"Key generated!\n%@\n\nExpires: %@", key[@"key"], key[@"expiry_date"]];
                    [self showAlert:@"Success" message:successMsg];
                } else {
                    [self showAlert:@"Success" message:@"Key generated successfully"];
                }
            } failure:^(NSError *error) {
                NSLog(@"❌ Failed to generate key: %@", error);
                NSString *errorMsg = [NSString stringWithFormat:@"Failed to generate key: %@", error.localizedDescription];
                [self showAlert:@"Error" message:errorMsg];
            }];
        }
    }]];
    
    [self presentViewController:alert animated:YES completion:nil];
}

#pragma mark - UITableView

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.keys.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellId = @"KeyCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellId];
        cell.backgroundColor = [UIColor colorWithWhite:0.1 alpha:1.0];
        cell.textLabel.textColor = [UIColor whiteColor];
        cell.textLabel.font = [UIFont fontWithName:@"Courier" size:14];
        cell.detailTextLabel.textColor = [UIColor colorWithWhite:0.7 alpha:1.0];
        cell.accessoryType = UITableViewCellAccessoryDetailButton;
    }
    
    NSDictionary *key = self.keys[indexPath.row];
    cell.textLabel.text = [NSString stringWithFormat:@"🔑 %@", key[@"key"]];
    cell.detailTextLabel.text = [NSString stringWithFormat:@"Package: %@ | Status: %@", key[@"package_name"], key[@"status"]];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSDictionary *key = self.keys[indexPath.row];
    NSString *keyId = key[@"id"];
    NSString *keyValue = key[@"key"];
    NSString *status = key[@"status"];
    BOOL isBanned = [status isEqualToString:@"banned"];
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Key Actions" message:keyValue preferredStyle:UIAlertControllerStyleActionSheet];
    
    // Copy Key
    [alert addAction:[UIAlertAction actionWithTitle:@"📋 Copy Key" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        UIPasteboard.generalPasteboard.string = keyValue;
        [self showAlert:@"Copied" message:@"Key copied to clipboard"];
    }]];
    
    // Reset Devices
    [alert addAction:[UIAlertAction actionWithTitle:@"🔄 Reset Devices" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        [self resetKey:keyId];
    }]];
    
    // Ban/Unban
    if (isBanned) {
        [alert addAction:[UIAlertAction actionWithTitle:@"✅ Unban Key" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            [self unbanKey:keyId];
        }]];
    } else {
        [alert addAction:[UIAlertAction actionWithTitle:@"🚫 Ban Key" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
            [self banKey:keyId];
        }]];
    }
    
    // Delete
    [alert addAction:[UIAlertAction actionWithTitle:@"🗑️ Delete Key" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
        [self deleteKey:keyId];
    }]];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)resetKey:(NSString *)keyId {
    UIAlertController *confirm = [UIAlertController alertControllerWithTitle:@"Reset Key" message:@"This will remove all bound devices. Continue?" preferredStyle:UIAlertControllerStyleAlert];
    
    [confirm addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    [confirm addAction:[UIAlertAction actionWithTitle:@"Reset" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
        [[APIManager sharedManager] resetKey:keyId success:^(NSDictionary *response) {
            [self loadKeys];
            [self showAlert:@"Success" message:response[@"message"]];
        } failure:^(NSError *error) {
            [self showAlert:@"Error" message:@"Failed to reset key"];
        }];
    }]];
    
    [self presentViewController:confirm animated:YES completion:nil];
}

- (void)banKey:(NSString *)keyId {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Ban Key" message:@"Enter ban message (shown to user)" preferredStyle:UIAlertControllerStyleAlert];
    
    [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.placeholder = @"e.g., Banned by DOX";
        textField.text = @"Banned by admin";
    }];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:@"Ban" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
        NSString *message = alert.textFields[0].text;
        
        [[APIManager sharedManager] banKey:keyId message:message success:^(NSDictionary *response) {
            [self loadKeys];
            [self showAlert:@"Success" message:@"Key banned successfully"];
        } failure:^(NSError *error) {
            [self showAlert:@"Error" message:@"Failed to ban key"];
        }];
    }]];
    
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)unbanKey:(NSString *)keyId {
    [[APIManager sharedManager] unbanKey:keyId success:^(NSDictionary *response) {
        [self loadKeys];
        [self showAlert:@"Success" message:@"Key unbanned successfully"];
    } failure:^(NSError *error) {
        [self showAlert:@"Error" message:@"Failed to unban key"];
    }];
}

- (void)deleteKey:(NSString *)keyId {
    UIAlertController *confirm = [UIAlertController alertControllerWithTitle:@"Delete Key" message:@"This action cannot be undone. Continue?" preferredStyle:UIAlertControllerStyleAlert];
    
    [confirm addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    [confirm addAction:[UIAlertAction actionWithTitle:@"Delete" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
        [[APIManager sharedManager] deleteKey:keyId success:^(NSDictionary *response) {
            [self loadKeys];
            [self showAlert:@"Success" message:@"Key deleted successfully"];
        } failure:^(NSError *error) {
            [self showAlert:@"Error" message:@"Failed to delete key"];
        }];
    }]];
    
    [self presentViewController:confirm animated:YES completion:nil];
}

- (void)showAlert:(NSString *)title message:(NSString *)message {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

@end
