//
//  LoginViewController.m
//  DOX O KDA
//

#import "LoginViewController.h"
#import "APIManager.h"
#import "MainTabBarController.h"

@interface LoginViewController ()
@property (nonatomic, strong) UITextField *usernameField;
@property (nonatomic, strong) UITextField *passwordField;
@property (nonatomic, strong) UIButton *loginButton;
@property (nonatomic, strong) UIActivityIndicatorView *activityIndicator;
@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor colorWithRed:0.05 green:0.05 blue:0.05 alpha:1.0];
    self.title = @"Admin Login";
    
    [self setupUI];
}

- (void)setupUI {
    UILabel *logoLabel = [[UILabel alloc] init];
    logoLabel.text = @"";
    logoLabel.font = [UIFont systemFontOfSize:80];
    logoLabel.textAlignment = NSTextAlignmentCenter;
    logoLabel.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:logoLabel];
    
    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.text = @"DOX API";
    titleLabel.font = [UIFont boldSystemFontOfSize:28];
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:titleLabel];
    
    UILabel *subtitleLabel = [[UILabel alloc] init];
    subtitleLabel.text = @"Please login to continue";
    subtitleLabel.font = [UIFont systemFontOfSize:14];
    subtitleLabel.textColor = [UIColor colorWithWhite:0.7 alpha:1.0];
    subtitleLabel.textAlignment = NSTextAlignmentCenter;
    subtitleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:subtitleLabel];
    
    self.usernameField = [[UITextField alloc] init];
    self.usernameField.placeholder = @"Username";
    self.usernameField.borderStyle = UITextBorderStyleRoundedRect;
    self.usernameField.backgroundColor = [UIColor colorWithWhite:0.15 alpha:1.0];
    self.usernameField.textColor = [UIColor whiteColor];
    self.usernameField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    self.usernameField.autocorrectionType = UITextAutocorrectionTypeNo;
    self.usernameField.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:self.usernameField];
    
    self.passwordField = [[UITextField alloc] init];
    self.passwordField.placeholder = @"Password";
    self.passwordField.borderStyle = UITextBorderStyleRoundedRect;
    self.passwordField.backgroundColor = [UIColor colorWithWhite:0.15 alpha:1.0];
    self.passwordField.textColor = [UIColor whiteColor];
    self.passwordField.secureTextEntry = YES;
    self.passwordField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    self.passwordField.autocorrectionType = UITextAutocorrectionTypeNo;
    self.passwordField.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:self.passwordField];
    
    self.loginButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [self.loginButton setTitle:@"Login" forState:UIControlStateNormal];
    [self.loginButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.loginButton.backgroundColor = [UIColor colorWithRed:0.13 green:0.59 blue:0.95 alpha:1.0];
    self.loginButton.layer.cornerRadius = 8;
    self.loginButton.titleLabel.font = [UIFont boldSystemFontOfSize:16];
    [self.loginButton addTarget:self action:@selector(loginButtonTapped) forControlEvents:UIControlEventTouchUpInside];
    self.loginButton.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:self.loginButton];
    
    if (@available(iOS 13.0, *)) {
        self.activityIndicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleLarge];
    } else {
        self.activityIndicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    }
    self.activityIndicator.color = [UIColor whiteColor];
    self.activityIndicator.hidesWhenStopped = YES;
    self.activityIndicator.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:self.activityIndicator];
    
    UILabel *defaultLabel = [[UILabel alloc] init];
    defaultLabel.text = @"Default: admin / admin123";
    defaultLabel.font = [UIFont systemFontOfSize:12];
    defaultLabel.textColor = [UIColor colorWithWhite:0.5 alpha:1.0];
    defaultLabel.textAlignment = NSTextAlignmentCenter;
    defaultLabel.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:defaultLabel];
    
    [NSLayoutConstraint activateConstraints:@[
        [logoLabel.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
        [logoLabel.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:60],
        
        [titleLabel.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
        [titleLabel.topAnchor constraintEqualToAnchor:logoLabel.bottomAnchor constant:20],
        
        [subtitleLabel.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
        [subtitleLabel.topAnchor constraintEqualToAnchor:titleLabel.bottomAnchor constant:10],
        
        [self.usernameField.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
        [self.usernameField.topAnchor constraintEqualToAnchor:subtitleLabel.bottomAnchor constant:40],
        [self.usernameField.widthAnchor constraintEqualToConstant:280],
        [self.usernameField.heightAnchor constraintEqualToConstant:44],
        
        [self.passwordField.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
        [self.passwordField.topAnchor constraintEqualToAnchor:self.usernameField.bottomAnchor constant:15],
        [self.passwordField.widthAnchor constraintEqualToConstant:280],
        [self.passwordField.heightAnchor constraintEqualToConstant:44],
        
        [self.loginButton.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
        [self.loginButton.topAnchor constraintEqualToAnchor:self.passwordField.bottomAnchor constant:25],
        [self.loginButton.widthAnchor constraintEqualToConstant:280],
        [self.loginButton.heightAnchor constraintEqualToConstant:50],
        
        [defaultLabel.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
        [defaultLabel.topAnchor constraintEqualToAnchor:self.loginButton.bottomAnchor constant:20],
        
        [self.activityIndicator.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
        [self.activityIndicator.centerYAnchor constraintEqualToAnchor:self.view.centerYAnchor]
    ]];
}

- (void)loginButtonTapped {
    NSString *username = self.usernameField.text;
    NSString *password = self.passwordField.text;
    
    if (username.length == 0 || password.length == 0) {
        [self showAlert:@"Error" message:@"Please enter username and password"];
        return;
    }
    
    [self.activityIndicator startAnimating];
    self.loginButton.enabled = NO;
    
    [[APIManager sharedManager] loginWithUsername:username password:password success:^(NSDictionary *response) {
        [self.activityIndicator stopAnimating];
        self.loginButton.enabled = YES;
        
        MainTabBarController *mainVC = [[MainTabBarController alloc] init];
        UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:mainVC];
        navController.modalPresentationStyle = UIModalPresentationFullScreen;
        [self presentViewController:navController animated:YES completion:nil];
        
    } failure:^(NSError *error) {
        [self.activityIndicator stopAnimating];
        self.loginButton.enabled = YES;
        [self showAlert:@"Login Failed" message:@"Invalid credentials"];
    }];
}

- (void)showAlert:(NSString *)title message:(NSString *)message {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

@end
