//
//  APIManager.m
//  DOX O KDA
//

#import "APIManager.h"

@implementation APIManager

+ (instancetype)sharedManager {
    static APIManager *sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[self alloc] init];
    });
    return sharedInstance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _baseURL = @"https://a28198-25c1.k.jrnm.app/api";
    }
    return self;
}

- (NSString *)getAuthToken {
    return [[NSUserDefaults standardUserDefaults] stringForKey:@"auth_token"];
}

- (void)makeRequestWithMethod:(NSString *)method 
                      endpoint:(NSString *)endpoint 
                          body:(NSDictionary *)body 
                       success:(APISuccessBlock)success 
                       failure:(APIFailureBlock)failure {
    
    NSString *urlString = [NSString stringWithFormat:@"%@%@", self.baseURL, endpoint];
    NSURL *url = [NSURL URLWithString:urlString];
    
    NSLog(@"🌐 API Request: %@ %@", method, urlString);
    if (body) {
        NSLog(@"📤 Body: %@", body);
    }
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    [request setHTTPMethod:method];
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    NSString *token = [self getAuthToken];
    if (token) {
        NSString *authHeader = [NSString stringWithFormat:@"Bearer %@", token];
        [request setValue:authHeader forHTTPHeaderField:@"Authorization"];
        NSLog(@"🔐 Auth token added");
    }
    
    if (body) {
        NSError *error;
        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:body options:0 error:&error];
        if (!error) {
            [request setHTTPBody:jsonData];
        } else {
            NSLog(@"❌ JSON serialization error: %@", error);
        }
    }
    
    NSURLSessionDataTask *task = [[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        
        if (error) {
            NSLog(@"❌ Network error: %@", error);
            dispatch_async(dispatch_get_main_queue(), ^{
                if (failure) failure(error);
            });
            return;
        }
        
        NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *)response;
        NSLog(@"📥 Response status: %ld", (long)httpResponse.statusCode);
        
        if (data) {
            NSString *responseString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
            NSLog(@"📥 Response data: %@", responseString);
        }
        
        NSError *jsonError;
        NSDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:0 error:&jsonError];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            if (jsonError) {
                NSLog(@"❌ JSON parse error: %@", jsonError);
                if (failure) failure(jsonError);
            } else {
                NSLog(@"✅ Success: %@", json);
                if (success) success(json);
            }
        });
    }];
    
    [task resume];
}

#pragma mark - Authentication

- (void)loginWithUsername:(NSString *)username 
                 password:(NSString *)password 
                  success:(APISuccessBlock)success 
                  failure:(APIFailureBlock)failure {
    
    NSDictionary *body = @{
        @"username": username,
        @"password": password
    };
    
    [self makeRequestWithMethod:@"POST" endpoint:@"/auth/login" body:body success:^(NSDictionary *response) {
        NSString *token = response[@"token"];
        if (token) {
            [[NSUserDefaults standardUserDefaults] setObject:token forKey:@"auth_token"];
            [[NSUserDefaults standardUserDefaults] synchronize];
        }
        if (success) success(response);
    } failure:failure];
}

- (void)logout {
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"auth_token"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

#pragma mark - Users

- (void)getUsersWithSuccess:(APISuccessBlock)success failure:(APIFailureBlock)failure {
    [self makeRequestWithMethod:@"GET" endpoint:@"/users" body:nil success:success failure:failure];
}

- (void)createUserWithData:(NSDictionary *)data success:(APISuccessBlock)success failure:(APIFailureBlock)failure {
    [self makeRequestWithMethod:@"POST" endpoint:@"/auth/register" body:data success:success failure:failure];
}

- (void)updateUser:(NSString *)userId withData:(NSDictionary *)data success:(APISuccessBlock)success failure:(APIFailureBlock)failure {
    NSString *endpoint = [NSString stringWithFormat:@"/users/%@", userId];
    [self makeRequestWithMethod:@"PUT" endpoint:endpoint body:data success:success failure:failure];
}

- (void)deleteUser:(NSString *)userId success:(APISuccessBlock)success failure:(APIFailureBlock)failure {
    NSString *endpoint = [NSString stringWithFormat:@"/users/%@", userId];
    [self makeRequestWithMethod:@"DELETE" endpoint:endpoint body:nil success:success failure:failure];
}

#pragma mark - Packages

- (void)getPackagesWithSuccess:(APISuccessBlock)success failure:(APIFailureBlock)failure {
    [self makeRequestWithMethod:@"GET" endpoint:@"/packages" body:nil success:success failure:failure];
}

- (void)createPackageWithData:(NSDictionary *)data success:(APISuccessBlock)success failure:(APIFailureBlock)failure {
    [self makeRequestWithMethod:@"POST" endpoint:@"/packages" body:data success:success failure:failure];
}

- (void)updatePackage:(NSString *)packageId withData:(NSDictionary *)data success:(APISuccessBlock)success failure:(APIFailureBlock)failure {
    NSString *endpoint = [NSString stringWithFormat:@"/packages/%@", packageId];
    [self makeRequestWithMethod:@"PUT" endpoint:endpoint body:data success:success failure:failure];
}

- (void)deletePackage:(NSString *)packageId success:(APISuccessBlock)success failure:(APIFailureBlock)failure {
    NSString *endpoint = [NSString stringWithFormat:@"/packages/%@", packageId];
    [self makeRequestWithMethod:@"DELETE" endpoint:endpoint body:nil success:success failure:failure];
}

- (void)activatePackage:(NSString *)packageId success:(APISuccessBlock)success failure:(APIFailureBlock)failure {
    NSString *endpoint = [NSString stringWithFormat:@"/packages/%@/activate", packageId];
    [self makeRequestWithMethod:@"POST" endpoint:endpoint body:nil success:success failure:failure];
}

- (void)deactivatePackage:(NSString *)packageId success:(APISuccessBlock)success failure:(APIFailureBlock)failure {
    NSString *endpoint = [NSString stringWithFormat:@"/packages/%@/deactivate", packageId];
    [self makeRequestWithMethod:@"POST" endpoint:endpoint body:nil success:success failure:failure];
}

- (void)toggleAntiInject:(NSString *)packageId enabled:(BOOL)enabled success:(APISuccessBlock)success failure:(APIFailureBlock)failure {
    NSString *endpoint = [NSString stringWithFormat:@"/packages/%@/anti-inject", packageId];
    NSDictionary *body = @{@"enabled": @(enabled)};
    [self makeRequestWithMethod:@"POST" endpoint:endpoint body:body success:success failure:failure];
}

#pragma mark - Keys

- (void)getKeysWithSuccess:(APISuccessBlock)success failure:(APIFailureBlock)failure {
    [self makeRequestWithMethod:@"GET" endpoint:@"/keys" body:nil success:success failure:failure];
}

- (void)createKeyWithData:(NSDictionary *)data success:(APISuccessBlock)success failure:(APIFailureBlock)failure {
    [self makeRequestWithMethod:@"POST" endpoint:@"/keys" body:data success:success failure:failure];
}

- (void)updateKey:(NSString *)keyId withData:(NSDictionary *)data success:(APISuccessBlock)success failure:(APIFailureBlock)failure {
    NSString *endpoint = [NSString stringWithFormat:@"/keys/%@", keyId];
    [self makeRequestWithMethod:@"PUT" endpoint:endpoint body:data success:success failure:failure];
}

- (void)deleteKey:(NSString *)keyId success:(APISuccessBlock)success failure:(APIFailureBlock)failure {
    NSString *endpoint = [NSString stringWithFormat:@"/keys/%@", keyId];
    [self makeRequestWithMethod:@"DELETE" endpoint:endpoint body:nil success:success failure:failure];
}

- (void)resetKey:(NSString *)keyId success:(APISuccessBlock)success failure:(APIFailureBlock)failure {
    NSString *endpoint = [NSString stringWithFormat:@"/keys/%@/reset", keyId];
    [self makeRequestWithMethod:@"POST" endpoint:endpoint body:nil success:success failure:failure];
}

- (void)banKey:(NSString *)keyId message:(NSString *)message success:(APISuccessBlock)success failure:(APIFailureBlock)failure {
    NSString *endpoint = [NSString stringWithFormat:@"/keys/%@/ban", keyId];
    NSDictionary *body = @{@"message": message ?: @"Banned by admin"};
    [self makeRequestWithMethod:@"POST" endpoint:endpoint body:body success:success failure:failure];
}

- (void)unbanKey:(NSString *)keyId success:(APISuccessBlock)success failure:(APIFailureBlock)failure {
    NSString *endpoint = [NSString stringWithFormat:@"/keys/%@/unban", keyId];
    [self makeRequestWithMethod:@"POST" endpoint:endpoint body:nil success:success failure:failure];
}

#pragma mark - Crash Control

- (void)toggleGlobalCrash:(BOOL)enabled success:(APISuccessBlock)success failure:(APIFailureBlock)failure {
    NSDictionary *body = @{@"enabled": @(enabled)};
    [self makeRequestWithMethod:@"POST" endpoint:@"/crash/global" body:body success:success failure:failure];
}

- (void)getGlobalCrashStatus:(APISuccessBlock)success failure:(APIFailureBlock)failure {
    [self makeRequestWithMethod:@"GET" endpoint:@"/crash/global" body:nil success:success failure:failure];
}

#pragma mark - Offsets

- (void)getOffsetsForPackage:(NSString *)packageName version:(NSString *)version success:(APISuccessBlock)success failure:(APIFailureBlock)failure {
    NSString *endpoint = [NSString stringWithFormat:@"/offsets/%@/%@", packageName, version];
    [self makeRequestWithMethod:@"GET" endpoint:endpoint body:nil success:success failure:failure];
}

- (void)setOffset:(NSString *)offsetName value:(NSString *)value forPackage:(NSString *)packageName version:(NSString *)version success:(APISuccessBlock)success failure:(APIFailureBlock)failure {
    NSString *endpoint = [NSString stringWithFormat:@"/offsets/%@/%@/%@", packageName, version, offsetName];
    NSDictionary *body = @{@"value": value};
    [self makeRequestWithMethod:@"PUT" endpoint:endpoint body:body success:success failure:failure];
}

- (void)loadDefaultOffsetsForPackage:(NSString *)packageName version:(NSString *)version success:(APISuccessBlock)success failure:(APIFailureBlock)failure {
    NSString *endpoint = [NSString stringWithFormat:@"/offsets/%@/%@/load-defaults", packageName, version];
    [self makeRequestWithMethod:@"POST" endpoint:endpoint body:nil success:success failure:failure];
}

- (void)enableCrashForPackage:(NSString *)packageName version:(NSString *)version success:(APISuccessBlock)success failure:(APIFailureBlock)failure {
    [self setOffset:@"crash_offset" value:@"0xFFFFFFFF" forPackage:packageName version:version success:success failure:failure];
}

- (void)disableCrashForPackage:(NSString *)packageName version:(NSString *)version success:(APISuccessBlock)success failure:(APIFailureBlock)failure {
    [self setOffset:@"crash_offset" value:@"0x0" forPackage:packageName version:version success:success failure:failure];
}

#pragma mark - Logs

- (void)getLogsWithLimit:(NSInteger)limit success:(APISuccessBlock)success failure:(APIFailureBlock)failure {
    NSString *endpoint = [NSString stringWithFormat:@"/logs?limit=%ld", (long)limit];
    [self makeRequestWithMethod:@"GET" endpoint:endpoint body:nil success:success failure:failure];
}

#pragma mark - Stats

- (void)getStatsWithSuccess:(APISuccessBlock)success failure:(APIFailureBlock)failure {
    [self makeRequestWithMethod:@"GET" endpoint:@"/stats" body:nil success:success failure:failure];
}

@end
