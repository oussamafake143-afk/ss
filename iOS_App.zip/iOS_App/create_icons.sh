#!/bin/bash

# Create simple app icons for testing
# This creates basic colored icons

echo "Creating app icons..."

cd Resources

# Check if ImageMagick is installed
if ! command -v convert &> /dev/null; then
    echo "ImageMagick not found. Installing..."
    echo "Please install ImageMagick:"
    echo "  Ubuntu/Debian: sudo apt-get install imagemagick"
    echo "  Mac: brew install imagemagick"
    exit 1
fi

# Create icons with blue background and white text
convert -size 120x120 xc:"#2196F3" \
        -gravity center \
        -pointsize 60 \
        -fill white \
        -annotate +0+0 "A" \
        AppIcon60x60@2x.png

convert -size 180x180 xc:"#2196F3" \
        -gravity center \
        -pointsize 90 \
        -fill white \
        -annotate +0+0 "A" \
        AppIcon60x60@3x.png

convert -size 152x152 xc:"#2196F3" \
        -gravity center \
        -pointsize 76 \
        -fill white \
        -annotate +0+0 "A" \
        AppIcon76x76@2x.png

convert -size 167x167 xc:"#2196F3" \
        -gravity center \
        -pointsize 83 \
        -fill white \
        -annotate +0+0 "A" \
        AppIcon83.5x83.5@2x.png

echo "✅ Icons created successfully!"
echo "Icons saved in Resources/"
