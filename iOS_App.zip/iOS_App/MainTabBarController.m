//
//  MainTabBarController.m
//  DOX O KDA
//

#import "MainTabBarController.h"
#import "DashboardViewController.h"
#import "PackagesViewController.h"
#import "KeysViewController.h"
#import "OffsetsViewController.h"
#import "SettingsViewController.h"

@implementation MainTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.tabBar.barStyle = UIBarStyleBlack;
    self.tabBar.translucent = NO;
    self.tabBar.barTintColor = [UIColor colorWithRed:0.05 green:0.05 blue:0.05 alpha:1.0];
    self.tabBar.tintColor = [UIColor colorWithRed:0.13 green:0.59 blue:0.95 alpha:1.0];
    
    DashboardViewController *dashboardVC = [[DashboardViewController alloc] init];
    UINavigationController *dashboardNav = [[UINavigationController alloc] initWithRootViewController:dashboardVC];
    dashboardNav.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"Dashboard" image:[UIImage systemImageNamed:@"chart.bar.fill"] tag:0];
    
    PackagesViewController *packagesVC = [[PackagesViewController alloc] init];
    UINavigationController *packagesNav = [[UINavigationController alloc] initWithRootViewController:packagesVC];
    packagesNav.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"Packages" image:[UIImage systemImageNamed:@"shippingbox.fill"] tag:1];
    
    KeysViewController *keysVC = [[KeysViewController alloc] init];
    UINavigationController *keysNav = [[UINavigationController alloc] initWithRootViewController:keysVC];
    keysNav.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"Keys" image:[UIImage systemImageNamed:@"key.fill"] tag:2];
    
    OffsetsViewController *offsetsVC = [[OffsetsViewController alloc] init];
    UINavigationController *offsetsNav = [[UINavigationController alloc] initWithRootViewController:offsetsVC];
    offsetsNav.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"Offsets" image:[UIImage systemImageNamed:@"slider.horizontal.3"] tag:3];
    
    SettingsViewController *settingsVC = [[SettingsViewController alloc] init];
    UINavigationController *settingsNav = [[UINavigationController alloc] initWithRootViewController:settingsVC];
    settingsNav.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"Settings" image:[UIImage systemImageNamed:@"gearshape.fill"] tag:4];
    
    self.viewControllers = @[dashboardNav, packagesNav, keysNav, offsetsNav, settingsNav];
}

@end
