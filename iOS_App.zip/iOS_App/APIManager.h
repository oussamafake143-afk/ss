//
//  APIManager.h
//  DOX O KDA
//
//  
//

#import <Foundation/Foundation.h>

typedef void (^APISuccessBlock)(NSDictionary *response);
typedef void (^APIFailureBlock)(NSError *error);

@interface APIManager : NSObject

+ (instancetype)sharedManager;

@property (nonatomic, strong) NSString *baseURL;

- (void)loginWithUsername:(NSString *)username 
                 password:(NSString *)password 
                  success:(APISuccessBlock)success 
                  failure:(APIFailureBlock)failure;

- (void)logout;

- (void)getUsersWithSuccess:(APISuccessBlock)success failure:(APIFailureBlock)failure;
- (void)createUserWithData:(NSDictionary *)data success:(APISuccessBlock)success failure:(APIFailureBlock)failure;
- (void)updateUser:(NSString *)userId withData:(NSDictionary *)data success:(APISuccessBlock)success failure:(APIFailureBlock)failure;
- (void)deleteUser:(NSString *)userId success:(APISuccessBlock)success failure:(APIFailureBlock)failure;

- (void)getPackagesWithSuccess:(APISuccessBlock)success failure:(APIFailureBlock)failure;
- (void)createPackageWithData:(NSDictionary *)data success:(APISuccessBlock)success failure:(APIFailureBlock)failure;
- (void)updatePackage:(NSString *)packageId withData:(NSDictionary *)data success:(APISuccessBlock)success failure:(APIFailureBlock)failure;
- (void)deletePackage:(NSString *)packageId success:(APISuccessBlock)success failure:(APIFailureBlock)failure;
- (void)activatePackage:(NSString *)packageId success:(APISuccessBlock)success failure:(APIFailureBlock)failure;
- (void)deactivatePackage:(NSString *)packageId success:(APISuccessBlock)success failure:(APIFailureBlock)failure;
- (void)toggleAntiInject:(NSString *)packageId enabled:(BOOL)enabled success:(APISuccessBlock)success failure:(APIFailureBlock)failure;

- (void)getKeysWithSuccess:(APISuccessBlock)success failure:(APIFailureBlock)failure;
- (void)createKeyWithData:(NSDictionary *)data success:(APISuccessBlock)success failure:(APIFailureBlock)failure;
- (void)updateKey:(NSString *)keyId withData:(NSDictionary *)data success:(APISuccessBlock)success failure:(APIFailureBlock)failure;
- (void)deleteKey:(NSString *)keyId success:(APISuccessBlock)success failure:(APIFailureBlock)failure;
- (void)resetKey:(NSString *)keyId success:(APISuccessBlock)success failure:(APIFailureBlock)failure;
- (void)banKey:(NSString *)keyId message:(NSString *)message success:(APISuccessBlock)success failure:(APIFailureBlock)failure;
- (void)unbanKey:(NSString *)keyId success:(APISuccessBlock)success failure:(APIFailureBlock)failure;

- (void)toggleGlobalCrash:(BOOL)enabled success:(APISuccessBlock)success failure:(APIFailureBlock)failure;
- (void)getGlobalCrashStatus:(APISuccessBlock)success failure:(APIFailureBlock)failure;

- (void)getOffsetsForPackage:(NSString *)packageName version:(NSString *)version success:(APISuccessBlock)success failure:(APIFailureBlock)failure;
- (void)setOffset:(NSString *)offsetName value:(NSString *)value forPackage:(NSString *)packageName version:(NSString *)version success:(APISuccessBlock)success failure:(APIFailureBlock)failure;
- (void)loadDefaultOffsetsForPackage:(NSString *)packageName version:(NSString *)version success:(APISuccessBlock)success failure:(APIFailureBlock)failure;
- (void)enableCrashForPackage:(NSString *)packageName version:(NSString *)version success:(APISuccessBlock)success failure:(APIFailureBlock)failure;
- (void)disableCrashForPackage:(NSString *)packageName version:(NSString *)version success:(APISuccessBlock)success failure:(APIFailureBlock)failure;

- (void)getLogsWithLimit:(NSInteger)limit success:(APISuccessBlock)success failure:(APIFailureBlock)failure;

- (void)getStatsWithSuccess:(APISuccessBlock)success failure:(APIFailureBlock)failure;

@end
