//
//  MainTabBarController.h
//  DOX O KDA
//

#import <UIKit/UIKit.h>

@interface MainTabBarController : UITabBarController

@end
