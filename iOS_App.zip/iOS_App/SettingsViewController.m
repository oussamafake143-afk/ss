//
//  SettingsViewController.m
//  DOX O KDA
//

#import "SettingsViewController.h"
#import "APIManager.h"
#import "LoginViewController.h"

@interface SettingsViewController () <UITableViewDelegate, UITableViewDataSource>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSArray *settingsData;
@end

@implementation SettingsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor colorWithRed:0.05 green:0.05 blue:0.05 alpha:1.0];
    self.title = @"Settings";
    
    [self setupData];
    [self setupTableView];
}

- (void)setupData {
    self.settingsData = @[
        @{@"title": @"Account", @"items": @[
            @{@"name": @"Change Password", @"icon": @"🔒"},
            @{@"name": @"Account Info", @"icon": @"👤"},
            @{@"name": @"Clear Cache", @"icon": @"🗑️"}
        ]},
        @{@"title": @"API", @"items": @[
            @{@"name": @"Server URL", @"icon": @"🌐", @"value": @"https://a28198-25c1.k.jrnm.app/"},
            @{@"name": @"API URL", @"icon": @"🔧", @"value": @"https://a28198-25c1.k.jrnm.app/api"}
        ]},
        @{@"title": @"Telegram Bot", @"items": @[
            @{@"name": @"Bot Token", @"icon": @"🤖", @"value": @"8537845521:AAGH..."},
            @{@"name": @"Admin Chat ID", @"icon": @"💬", @"value": @"7446601898"}
        ]},
        @{@"title": @"About", @"items": @[
            @{@"name": @"Version", @"icon": @"ℹ️", @"value": @"1.0.0"},
            @{@"name": @"Developer", @"icon": @"👨‍💻", @"value": @"OSM DOX"},
            @{@"name": @"Logout", @"icon": @"🚪"}
        ]}
    ];
}

- (void)setupTableView {
    self.tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStyleGrouped];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.backgroundColor = [UIColor colorWithRed:0.05 green:0.05 blue:0.05 alpha:1.0];
    self.tableView.separatorColor = [UIColor colorWithWhite:0.2 alpha:1.0];
    self.tableView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    
    UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 100)];
    footerView.backgroundColor = [UIColor clearColor];
    
    UILabel *creditLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 20, self.view.bounds.size.width, 60)];
    creditLabel.numberOfLines = 3;
    creditLabel.textAlignment = NSTextAlignmentCenter;
    creditLabel.textColor = [UIColor colorWithWhite:0.5 alpha:1.0];
    
    NSMutableAttributedString *attributedText = [[NSMutableAttributedString alloc] init];
    
    NSDictionary *normalAttrs = @{
        NSFontAttributeName: [UIFont systemFontOfSize:13],
        NSForegroundColorAttributeName: [UIColor colorWithWhite:0.5 alpha:1.0]
    };
    [attributedText appendAttributedString:[[NSAttributedString alloc] initWithString:@"Developed by\n" attributes:normalAttrs]];
    
    NSDictionary *boldAttrs = @{
        NSFontAttributeName: [UIFont boldSystemFontOfSize:16],
        NSForegroundColorAttributeName: [UIColor colorWithRed:0.13 green:0.59 blue:0.95 alpha:1.0]
    };
    [attributedText appendAttributedString:[[NSAttributedString alloc] initWithString:@"OSM DOX\n" attributes:boldAttrs]];
    
    NSDictionary *smallAttrs = @{
        NSFontAttributeName: [UIFont systemFontOfSize:11],
        NSForegroundColorAttributeName: [UIColor colorWithWhite:0.4 alpha:1.0]
    };
    [attributedText appendAttributedString:[[NSAttributedString alloc] initWithString:@"© 2026" attributes:smallAttrs]];
    
    creditLabel.attributedText = attributedText;
    [footerView addSubview:creditLabel];
    
    self.tableView.tableFooterView = footerView;
    
    [self.view addSubview:self.tableView];
}

#pragma mark - UITableView

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.settingsData.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSDictionary *sectionData = self.settingsData[section];
    NSArray *items = sectionData[@"items"];
    return items.count;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    NSDictionary *sectionData = self.settingsData[section];
    return sectionData[@"title"];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellId = @"SettingCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:cellId];
        cell.backgroundColor = [UIColor colorWithWhite:0.1 alpha:1.0];
        cell.textLabel.textColor = [UIColor whiteColor];
        cell.detailTextLabel.textColor = [UIColor colorWithWhite:0.7 alpha:1.0];
        cell.detailTextLabel.font = [UIFont systemFontOfSize:12];
    }
    
    NSDictionary *sectionData = self.settingsData[indexPath.section];
    NSArray *items = sectionData[@"items"];
    NSDictionary *item = items[indexPath.row];
    
    cell.textLabel.text = [NSString stringWithFormat:@"%@ %@", item[@"icon"], item[@"name"]];
    cell.detailTextLabel.text = item[@"value"];
    
    if ([item[@"name"] isEqualToString:@"Logout"]) {
        cell.textLabel.textColor = [UIColor redColor];
    } else {
        cell.textLabel.textColor = [UIColor whiteColor];
    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSDictionary *sectionData = self.settingsData[indexPath.section];
    NSArray *items = sectionData[@"items"];
    NSDictionary *item = items[indexPath.row];
    NSString *name = item[@"name"];
    
    if ([name isEqualToString:@"Logout"]) {
        [self logout];
    } else if ([name isEqualToString:@"Change Password"]) {
        [self changePassword];
    } else if ([name isEqualToString:@"Account Info"]) {
        [self showAccountInfo];
    } else if ([name isEqualToString:@"Clear Cache"]) {
        [self clearCache];
    } else if (item[@"value"]) {
        UIPasteboard.generalPasteboard.string = item[@"value"];
        [self showAlert:@"Copied" message:@"Value copied to clipboard"];
    }
}

- (void)logout {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Logout" message:@"Are you sure you want to logout?" preferredStyle:UIAlertControllerStyleAlert];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:@"Logout" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
        [[APIManager sharedManager] logout];
        
        LoginViewController *loginVC = [[LoginViewController alloc] init];
        UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:loginVC];
        navController.modalPresentationStyle = UIModalPresentationFullScreen;
        [self presentViewController:navController animated:YES completion:nil];
    }]];
    
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)changePassword {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Change Password" message:@"Enter new password" preferredStyle:UIAlertControllerStyleAlert];
    
    [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.placeholder = @"New Password";
        textField.secureTextEntry = YES;
    }];
    
    [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.placeholder = @"Confirm Password";
        textField.secureTextEntry = YES;
    }];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:@"Change" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        NSString *password1 = alert.textFields[0].text;
        NSString *password2 = alert.textFields[1].text;
        
        if (![password1 isEqualToString:password2]) {
            [self showAlert:@"Error" message:@"Passwords do not match"];
            return;
        }
        
        if (password1.length < 6) {
            [self showAlert:@"Error" message:@"Password must be at least 6 characters"];
            return;
        }
        
        [self showAlert:@"Success" message:@"Password changed successfully"];
    }]];
    
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)showAccountInfo {
    NSString *message = @"Username: admin\nRole: Admin\nEmail: admin@example.com";
    [self showAlert:@"Account Info" message:message];
}

- (void)clearCache {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Clear Cache" message:@"This will clear all cached data and logout. Continue?" preferredStyle:UIAlertControllerStyleAlert];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:@"Clear" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
        NSString *appDomain = [[NSBundle mainBundle] bundleIdentifier];
        [[NSUserDefaults standardUserDefaults] removePersistentDomainForName:appDomain];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        [[APIManager sharedManager] logout];
        
        LoginViewController *loginVC = [[LoginViewController alloc] init];
        UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:loginVC];
        navController.modalPresentationStyle = UIModalPresentationFullScreen;
        [self presentViewController:navController animated:YES completion:nil];
    }]];
    
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)showAlert:(NSString *)title message:(NSString *)message {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

@end
