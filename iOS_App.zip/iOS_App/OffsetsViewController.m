//
//  OffsetsViewController.m
//  DOX O KDA
//

#import "OffsetsViewController.h"
#import "APIManager.h"

@interface OffsetsViewController () <UITableViewDelegate, UITableViewDataSource, UIPickerViewDelegate, UIPickerViewDataSource>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSDictionary *offsets;
@property (nonatomic, strong) NSArray *packages;
@property (nonatomic, strong) NSString *selectedPackage;
@property (nonatomic, strong) NSString *selectedVersion;
@property (nonatomic, strong) UIButton *crashButton;
@property (nonatomic, strong) UIButton *globalCrashButton;
@property (nonatomic, strong) UIButton *antiInjectButton;
@property (nonatomic, strong) UILabel *packageLabel;
@property (nonatomic, strong) UILabel *versionLabel;
@property (nonatomic, strong) UILabel *offsetCountLabel;
@property (nonatomic, assign) BOOL globalCrashEnabled;
@property (nonatomic, assign) BOOL antiInjectEnabled;
@end

@implementation OffsetsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor colorWithRed:0.05 green:0.05 blue:0.05 alpha:1.0];
    self.title = @"Offsets";
    
    self.selectedPackage = @"Lmjhed";
    self.selectedVersion = @"1.0.0";
    
    [self setupUI];
    [self loadPackages];
    [self loadGlobalCrashStatus];
}

- (void)setupUI {
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 280)];
    headerView.backgroundColor = [UIColor colorWithWhite:0.08 alpha:1.0];
    [self.view addSubview:headerView];
    
=    UIView *infoCard = [[UIView alloc] initWithFrame:CGRectMake(15, 15, self.view.bounds.size.width - 30, 100)];
    infoCard.backgroundColor = [UIColor colorWithWhite:0.12 alpha:1.0];
    infoCard.layer.cornerRadius = 12;
    [headerView addSubview:infoCard];
    
    self.packageLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, 15, infoCard.bounds.size.width - 30, 25)];
    self.packageLabel.text = [NSString stringWithFormat:@"📦 %@", self.selectedPackage];
    self.packageLabel.textColor = [UIColor whiteColor];
    self.packageLabel.font = [UIFont boldSystemFontOfSize:18];
    [infoCard addSubview:self.packageLabel];
    
    self.versionLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, 45, infoCard.bounds.size.width - 30, 20)];
    self.versionLabel.text = [NSString stringWithFormat:@"Version: %@", self.selectedVersion];
    self.versionLabel.textColor = [UIColor colorWithWhite:0.6 alpha:1.0];
    self.versionLabel.font = [UIFont systemFontOfSize:14];
    [infoCard addSubview:self.versionLabel];
    
    self.offsetCountLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, 70, infoCard.bounds.size.width - 30, 20)];
    self.offsetCountLabel.text = @"Offsets: 0";
    self.offsetCountLabel.textColor = [UIColor colorWithRed:0.13 green:0.59 blue:0.95 alpha:1.0];
    self.offsetCountLabel.font = [UIFont systemFontOfSize:13];
    [infoCard addSubview:self.offsetCountLabel];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(selectPackage)];
    [infoCard addGestureRecognizer:tap];
    
    CGFloat buttonY = 125;
    CGFloat buttonWidth = (self.view.bounds.size.width - 45) / 2;
    
    self.crashButton = [UIButton buttonWithType:UIButtonTypeSystem];
    self.crashButton.frame = CGRectMake(15, buttonY, buttonWidth, 44);
    [self.crashButton setTitle:@"✅ Crash: OFF" forState:UIControlStateNormal];
    self.crashButton.backgroundColor = [UIColor colorWithRed:0.13 green:0.59 blue:0.95 alpha:1.0];
    [self.crashButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.crashButton.titleLabel.font = [UIFont boldSystemFontOfSize:14];
    self.crashButton.layer.cornerRadius = 8;
    [self.crashButton addTarget:self action:@selector(toggleCrash) forControlEvents:UIControlEventTouchUpInside];
    [headerView addSubview:self.crashButton];
    
    self.globalCrashButton = [UIButton buttonWithType:UIButtonTypeSystem];
    self.globalCrashButton.frame = CGRectMake(buttonWidth + 22, buttonY, buttonWidth, 44);
    [self.globalCrashButton setTitle:@"💥 Global: OFF" forState:UIControlStateNormal];
    self.globalCrashButton.backgroundColor = [UIColor colorWithRed:0.2 green:0.2 blue:0.2 alpha:1.0];
    [self.globalCrashButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.globalCrashButton.titleLabel.font = [UIFont boldSystemFontOfSize:14];
    self.globalCrashButton.layer.cornerRadius = 8;
    [self.globalCrashButton addTarget:self action:@selector(toggleGlobalCrash) forControlEvents:UIControlEventTouchUpInside];
    [headerView addSubview:self.globalCrashButton];
    
    self.antiInjectButton = [UIButton buttonWithType:UIButtonTypeSystem];
    self.antiInjectButton.frame = CGRectMake(15, buttonY + 54, self.view.bounds.size.width - 30, 44);
    [self.antiInjectButton setTitle:@"🛡️ Anti-Inject: ON" forState:UIControlStateNormal];
    self.antiInjectButton.backgroundColor = [UIColor colorWithRed:0.13 green:0.59 blue:0.95 alpha:1.0];
    [self.antiInjectButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.antiInjectButton.titleLabel.font = [UIFont boldSystemFontOfSize:14];
    self.antiInjectButton.layer.cornerRadius = 8;
    [self.antiInjectButton addTarget:self action:@selector(toggleAntiInject) forControlEvents:UIControlEventTouchUpInside];
    [headerView addSubview:self.antiInjectButton];
    
    CGFloat tableY = 280;
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, tableY, self.view.bounds.size.width, self.view.bounds.size.height - tableY - 49) style:UITableViewStyleGrouped];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.backgroundColor = [UIColor colorWithRed:0.05 green:0.05 blue:0.05 alpha:1.0];
    self.tableView.separatorColor = [UIColor colorWithWhite:0.2 alpha:1.0];
    [self.view addSubview:self.tableView];
    
    self.navigationItem.rightBarButtonItems = @[
        [[UIBarButtonItem alloc] initWithTitle:@"Defaults" style:UIBarButtonItemStylePlain target:self action:@selector(loadDefaults)],
        [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addOffset)]
    ];
    
    UIRefreshControl *refreshControl = [[UIRefreshControl alloc] init];
    [refreshControl addTarget:self action:@selector(loadOffsets) forControlEvents:UIControlEventValueChanged];
    self.tableView.refreshControl = refreshControl;
}

- (void)loadPackages {
    [[APIManager sharedManager] getPackagesWithSuccess:^(NSDictionary *response) {
        self.packages = response[@"packages"];
        [self loadOffsets];
    } failure:^(NSError *error) {
        [self loadOffsets];
    }];
}

- (void)loadOffsets {
    [[APIManager sharedManager] getOffsetsForPackage:self.selectedPackage version:self.selectedVersion success:^(NSDictionary *response) {
        [self.tableView.refreshControl endRefreshing];
        self.offsets = response[@"offsets"];
        self.offsetCountLabel.text = [NSString stringWithFormat:@"Offsets: %lu", (unsigned long)self.offsets.count];
        [self.tableView reloadData];
        [self updateCrashStatus];
    } failure:^(NSError *error) {
        [self.tableView.refreshControl endRefreshing];
        self.offsets = @{};
        self.offsetCountLabel.text = @"Offsets: 0";
        [self.tableView reloadData];
    }];
}

- (void)loadGlobalCrashStatus {
    [[APIManager sharedManager] getGlobalCrashStatus:^(NSDictionary *response) {
        self.globalCrashEnabled = [response[@"enabled"] boolValue];
        [self updateGlobalCrashButton];
    } failure:nil];
}

- (void)updateCrashStatus {
    NSString *crashValue = self.offsets[@"crash_offset"];
    BOOL crashEnabled = ![crashValue isEqualToString:@"0x0"] && ![crashValue isEqualToString:@"0"];
    
    if (crashEnabled) {
        [self.crashButton setTitle:@"🚨 Crash: ON" forState:UIControlStateNormal];
        self.crashButton.backgroundColor = [UIColor colorWithRed:0.9 green:0.2 blue:0.2 alpha:1.0];
    } else {
        [self.crashButton setTitle:@"✅ Crash: OFF" forState:UIControlStateNormal];
        self.crashButton.backgroundColor = [UIColor colorWithRed:0.13 green:0.59 blue:0.95 alpha:1.0];
    }
}

- (void)updateGlobalCrashButton {
    if (self.globalCrashEnabled) {
        [self.globalCrashButton setTitle:@"💥 Global: ON" forState:UIControlStateNormal];
        self.globalCrashButton.backgroundColor = [UIColor colorWithRed:0.9 green:0.2 blue:0.2 alpha:1.0];
    } else {
        [self.globalCrashButton setTitle:@"💥 Global: OFF" forState:UIControlStateNormal];
        self.globalCrashButton.backgroundColor = [UIColor colorWithRed:0.2 green:0.2 blue:0.2 alpha:1.0];
    }
}

- (void)selectPackage {
    if (!self.packages || self.packages.count == 0) {
        [self showAlert:@"No Packages" message:@"Create a package first"];
        return;
    }
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Select Package" message:@"Choose package and version" preferredStyle:UIAlertControllerStyleAlert];
    
    UIPickerView *picker = [[UIPickerView alloc] initWithFrame:CGRectMake(0, 0, 250, 150)];
    picker.delegate = self;
    picker.dataSource = self;
    
    [alert.view addSubview:picker];
    
    NSLayoutConstraint *constraint = [NSLayoutConstraint constraintWithItem:alert.view
                                                                  attribute:NSLayoutAttributeHeight
                                                                  relatedBy:NSLayoutRelationEqual
                                                                     toItem:nil
                                                                  attribute:NSLayoutAttributeNotAnAttribute
                                                                 multiplier:1
                                                                   constant:300];
    [alert.view addConstraint:constraint];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:@"Select" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        NSInteger row = [picker selectedRowInComponent:0];
        if (row < self.packages.count) {
            NSDictionary *pkg = self.packages[row];
            self.selectedPackage = pkg[@"name"];
            self.packageLabel.text = [NSString stringWithFormat:@"📦 %@", self.selectedPackage];
            [self loadOffsets];
        }
    }]];
    
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)toggleCrash {
    NSString *crashValue = self.offsets[@"crash_offset"];
    BOOL currentlyEnabled = ![crashValue isEqualToString:@"0x0"] && ![crashValue isEqualToString:@"0"];
    
    if (currentlyEnabled) {
        [[APIManager sharedManager] disableCrashForPackage:self.selectedPackage version:self.selectedVersion success:^(NSDictionary *response) {
            [self loadOffsets];
            [self showAlert:@"Success" message:@"Crash disabled"];
        } failure:^(NSError *error) {
            [self showAlert:@"Error" message:@"Failed to disable crash"];
        }];
    } else {
        [[APIManager sharedManager] enableCrashForPackage:self.selectedPackage version:self.selectedVersion success:^(NSDictionary *response) {
            [self loadOffsets];
            [self showAlert:@"Warning" message:@"Crash enabled! App will crash on launch."];
        } failure:^(NSError *error) {
            [self showAlert:@"Error" message:@"Failed to enable crash"];
        }];
    }
}

- (void)toggleGlobalCrash {
    BOOL newState = !self.globalCrashEnabled;
    
    NSString *message = newState ? @"⚠️ This will crash ALL users immediately!" : @"Disable global crash?";
    
    UIAlertController *confirm = [UIAlertController alertControllerWithTitle:@"Confirm" message:message preferredStyle:UIAlertControllerStyleAlert];
    
    [confirm addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    [confirm addAction:[UIAlertAction actionWithTitle:newState ? @"Enable" : @"Disable" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
        [[APIManager sharedManager] toggleGlobalCrash:newState success:^(NSDictionary *response) {
            self.globalCrashEnabled = newState;
            [self updateGlobalCrashButton];
            [self showAlert:@"Success" message:response[@"message"]];
        } failure:^(NSError *error) {
            [self showAlert:@"Error" message:@"Failed to toggle global crash"];
        }];
    }]];
    
    [self presentViewController:confirm animated:YES completion:nil];
}

- (void)toggleAntiInject {
    self.antiInjectEnabled = !self.antiInjectEnabled;
    
    [[APIManager sharedManager] toggleAntiInject:self.selectedPackage enabled:self.antiInjectEnabled success:^(NSDictionary *response) {
        if (self.antiInjectEnabled) {
            [self.antiInjectButton setTitle:@"🛡️ Anti-Inject: ON" forState:UIControlStateNormal];
            self.antiInjectButton.backgroundColor = [UIColor colorWithRed:0.13 green:0.59 blue:0.95 alpha:1.0];
        } else {
            [self.antiInjectButton setTitle:@"⚠️ Anti-Inject: OFF" forState:UIControlStateNormal];
            self.antiInjectButton.backgroundColor = [UIColor colorWithRed:0.9 green:0.5 blue:0.2 alpha:1.0];
        }
        [self showAlert:@"Success" message:response[@"message"]];
    } failure:^(NSError *error) {
        self.antiInjectEnabled = !self.antiInjectEnabled; // Revert
        [self showAlert:@"Error" message:@"Failed to toggle anti-inject"];
    }];
}

- (void)loadDefaults {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Load Defaults" message:@"This will load default offsets for Lmjhed. Continue?" preferredStyle:UIAlertControllerStyleAlert];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:@"Load" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        [[APIManager sharedManager] loadDefaultOffsetsForPackage:self.selectedPackage version:self.selectedVersion success:^(NSDictionary *response) {
            [self loadOffsets];
            [self showAlert:@"Success" message:@"Default offsets loaded"];
        } failure:^(NSError *error) {
            [self showAlert:@"Error" message:@"Failed to load defaults"];
        }];
    }]];
    
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)addOffset {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Add Offset" message:@"Enter offset details" preferredStyle:UIAlertControllerStyleAlert];
    
    [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.placeholder = @"Offset Name (e.g., GetHp)";
    }];
    
    [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.placeholder = @"Value (e.g., 0x4A8478C)";
    }];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:@"Add" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        NSString *name = alert.textFields[0].text;
        NSString *value = alert.textFields[1].text;
        
        if (name.length > 0 && value.length > 0) {
            [[APIManager sharedManager] setOffset:name value:value forPackage:self.selectedPackage version:self.selectedVersion success:^(NSDictionary *response) {
                [self loadOffsets];
                [self showAlert:@"Success" message:@"Offset added"];
            } failure:^(NSError *error) {
                [self showAlert:@"Error" message:@"Failed to add offset"];
            }];
        }
    }]];
    
    [self presentViewController:alert animated:YES completion:nil];
}

#pragma mark - UIPickerView

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return self.packages.count;
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    NSDictionary *pkg = self.packages[row];
    return pkg[@"name"];
}

#pragma mark - UITableView

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return @"Offsets";
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.offsets.allKeys.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellId = @"OffsetCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:cellId];
        cell.backgroundColor = [UIColor colorWithWhite:0.1 alpha:1.0];
        cell.textLabel.textColor = [UIColor whiteColor];
        cell.textLabel.font = [UIFont systemFontOfSize:14];
        cell.detailTextLabel.textColor = [UIColor colorWithRed:0.13 green:0.59 blue:0.95 alpha:1.0];
        cell.detailTextLabel.font = [UIFont fontWithName:@"Courier" size:12];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    
    NSArray *keys = [self.offsets.allKeys sortedArrayUsingSelector:@selector(compare:)];
    NSString *key = keys[indexPath.row];
    NSString *value = self.offsets[key];
    
    cell.textLabel.text = key;
    cell.detailTextLabel.text = value;
    
    if ([key isEqualToString:@"crash_offset"]) {
        cell.textLabel.textColor = [UIColor colorWithRed:0.9 green:0.2 blue:0.2 alpha:1.0];
    } else {
        cell.textLabel.textColor = [UIColor whiteColor];
    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSArray *keys = [self.offsets.allKeys sortedArrayUsingSelector:@selector(compare:)];
    NSString *key = keys[indexPath.row];
    NSString *value = self.offsets[key];
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Edit Offset" message:key preferredStyle:UIAlertControllerStyleAlert];
    
    [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.text = value;
        textField.placeholder = @"Value (e.g., 0x4A8478C)";
        textField.font = [UIFont fontWithName:@"Courier" size:14];
    }];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:@"Update" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        NSString *newValue = alert.textFields[0].text;
        
        [[APIManager sharedManager] setOffset:key value:newValue forPackage:self.selectedPackage version:self.selectedVersion success:^(NSDictionary *response) {
            [self loadOffsets];
            [self showAlert:@"Success" message:@"Offset updated"];
        } failure:^(NSError *error) {
            [self showAlert:@"Error" message:@"Failed to update offset"];
        }];
    }]];
    
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)showAlert:(NSString *)title message:(NSString *)message {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

@end
