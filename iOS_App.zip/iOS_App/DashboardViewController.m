//
//  DashboardViewController.m
//  DOX O KDA
//

#import "DashboardViewController.h"
#import "APIManager.h"

@interface DashboardViewController ()
@property (nonatomic, strong) UILabel *totalUsersLabel;
@property (nonatomic, strong) UILabel *activeKeysLabel;
@property (nonatomic, strong) UILabel *totalPackagesLabel;
@property (nonatomic, strong) UIRefreshControl *refreshControl;
@end

@implementation DashboardViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor colorWithRed:0.05 green:0.05 blue:0.05 alpha:1.0];
    self.title = @"Dashboard";
    
    [self setupUI];
    [self loadStats];
}

- (void)setupUI {
    UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:self.view.bounds];
    scrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [self.view addSubview:scrollView];
    
    self.refreshControl = [[UIRefreshControl alloc] init];
    [self.refreshControl addTarget:self action:@selector(loadStats) forControlEvents:UIControlEventValueChanged];
    scrollView.refreshControl = self.refreshControl;
    
    CGFloat yOffset = 20;
    CGFloat cardHeight = 100;
    CGFloat padding = 20;
    CGFloat spacing = 15;
    
    UIView *usersCard = [self createStatCardWithTitle:@"Total Users" value:@"0" icon:@"👥"];
    usersCard.frame = CGRectMake(padding, yOffset, self.view.bounds.size.width - (padding * 2), cardHeight);
    self.totalUsersLabel = (UILabel *)[usersCard viewWithTag:100];
    [scrollView addSubview:usersCard];
    yOffset += cardHeight + spacing;
    
    UIView *keysCard = [self createStatCardWithTitle:@"Active Keys" value:@"0" icon:@"🔑"];
    keysCard.frame = CGRectMake(padding, yOffset, self.view.bounds.size.width - (padding * 2), cardHeight);
    self.activeKeysLabel = (UILabel *)[keysCard viewWithTag:100];
    [scrollView addSubview:keysCard];
    yOffset += cardHeight + spacing;
    
    UIView *packagesCard = [self createStatCardWithTitle:@"Packages" value:@"0" icon:@"📦"];
    packagesCard.frame = CGRectMake(padding, yOffset, self.view.bounds.size.width - (padding * 2), cardHeight);
    self.totalPackagesLabel = (UILabel *)[packagesCard viewWithTag:100];
    [scrollView addSubview:packagesCard];
    yOffset += cardHeight + spacing;
    
    scrollView.contentSize = CGSizeMake(self.view.bounds.size.width, yOffset);
}

- (UIView *)createStatCardWithTitle:(NSString *)title value:(NSString *)value icon:(NSString *)icon {
    UIView *card = [[UIView alloc] init];
    card.backgroundColor = [UIColor colorWithWhite:0.1 alpha:1.0];
    card.layer.cornerRadius = 12;
    
    UILabel *iconLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 30, 60, 40)];
    iconLabel.text = icon;
    iconLabel.font = [UIFont systemFontOfSize:40];
    iconLabel.textAlignment = NSTextAlignmentCenter;
    [card addSubview:iconLabel];
    
    UILabel *valueLabel = [[UILabel alloc] initWithFrame:CGRectMake(100, 20, 200, 40)];
    valueLabel.text = value;
    valueLabel.font = [UIFont boldSystemFontOfSize:32];
    valueLabel.textColor = [UIColor whiteColor];
    valueLabel.tag = 100;
    [card addSubview:valueLabel];
    
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(100, 60, 200, 20)];
    titleLabel.text = title;
    titleLabel.font = [UIFont systemFontOfSize:14];
    titleLabel.textColor = [UIColor colorWithWhite:0.7 alpha:1.0];
    [card addSubview:titleLabel];
    
    return card;
}

- (void)loadStats {
    [[APIManager sharedManager] getStatsWithSuccess:^(NSDictionary *response) {
        [self.refreshControl endRefreshing];
        
        if (response[@"stats"]) {
            NSDictionary *stats = response[@"stats"];
            
            NSNumber *totalUsers = stats[@"total_users"];
            self.totalUsersLabel.text = totalUsers ? [NSString stringWithFormat:@"%@", totalUsers] : @"0";
            
            NSNumber *activeUsers = stats[@"active_users"];
            self.activeKeysLabel.text = activeUsers ? [NSString stringWithFormat:@"%@", activeUsers] : @"0";
            
            [[APIManager sharedManager] getPackagesWithSuccess:^(NSDictionary *packagesResponse) {
                NSArray *packages = packagesResponse[@"packages"];
                self.totalPackagesLabel.text = [NSString stringWithFormat:@"%lu", (unsigned long)packages.count];
            } failure:nil];
        } else {
            self.totalUsersLabel.text = @"0";
            self.activeKeysLabel.text = @"0";
            self.totalPackagesLabel.text = @"0";
        }
        
    } failure:^(NSError *error) {
        [self.refreshControl endRefreshing];
        NSString *errorMsg = [NSString stringWithFormat:@"Failed to load stats: %@", error.localizedDescription];
        [self showAlert:@"Error" message:errorMsg];
        
        self.totalUsersLabel.text = @"0";
        self.activeKeysLabel.text = @"0";
        self.totalPackagesLabel.text = @"0";
    }];
}

- (void)showAlert:(NSString *)title message:(NSString *)message {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

@end
