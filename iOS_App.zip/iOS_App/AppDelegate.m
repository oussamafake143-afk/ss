//
//  AppDelegate.m
//  DOX O KDA
//

#import "AppDelegate.h"
#import "LoginViewController.h"
#import "MainTabBarController.h"

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.window.backgroundColor = [UIColor blackColor];
    
    NSString *token = [[NSUserDefaults standardUserDefaults] stringForKey:@"auth_token"];
    
    UIViewController *rootViewController;
    if (token && token.length > 0) {
        // User is logged in, show main app
        rootViewController = [[MainTabBarController alloc] init];
    } else {
        // User not logged in, show login
        rootViewController = [[LoginViewController alloc] init];
    }
    
    UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:rootViewController];
    navController.navigationBar.barStyle = UIBarStyleBlack;
    navController.navigationBar.translucent = NO;
    navController.navigationBar.barTintColor = [UIColor colorWithRed:0.05 green:0.05 blue:0.05 alpha:1.0];
    navController.navigationBar.tintColor = [UIColor colorWithRed:0.13 green:0.59 blue:0.95 alpha:1.0];
    [navController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName: [UIColor whiteColor]}];
    
    self.window.rootViewController = navController;
    [self.window makeKeyAndVisible];
    
    return YES;
}

@end
