//
//  PackagesViewController.m
//  DOX O KDA
//

#import "PackagesViewController.h"
#import "APIManager.h"

@interface PackagesViewController () <UITableViewDelegate, UITableViewDataSource>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSArray *packages;
@end

@implementation PackagesViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor colorWithRed:0.05 green:0.05 blue:0.05 alpha:1.0];
    self.title = @"Packages";
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addPackage)];
    
    [self setupTableView];
    [self loadPackages];
}

- (void)setupTableView {
    self.tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.backgroundColor = [UIColor colorWithRed:0.05 green:0.05 blue:0.05 alpha:1.0];
    self.tableView.separatorColor = [UIColor colorWithWhite:0.2 alpha:1.0];
    self.tableView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [self.view addSubview:self.tableView];
    
    UIRefreshControl *refreshControl = [[UIRefreshControl alloc] init];
    [refreshControl addTarget:self action:@selector(loadPackages) forControlEvents:UIControlEventValueChanged];
    self.tableView.refreshControl = refreshControl;
}

- (void)loadPackages {
    [[APIManager sharedManager] getPackagesWithSuccess:^(NSDictionary *response) {
        [self.tableView.refreshControl endRefreshing];
        
        if (response[@"packages"]) {
            self.packages = response[@"packages"];
            NSLog(@"✅ Loaded %lu packages", (unsigned long)self.packages.count);
        } else {
            self.packages = @[];
            NSLog(@"⚠️ No packages in response");
        }
        
        [self.tableView reloadData];
    } failure:^(NSError *error) {
        [self.tableView.refreshControl endRefreshing];
        NSString *errorMsg = [NSString stringWithFormat:@"Failed to load packages: %@", error.localizedDescription];
        NSLog(@"❌ Error loading packages: %@", error);
        [self showAlert:@"Error" message:errorMsg];
    }];
}

- (void)addPackage {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Add Package" message:@"Enter package name" preferredStyle:UIAlertControllerStyleAlert];
    
    [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.placeholder = @"Package Name (e.g., DOX)";
    }];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:@"Add" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        NSString *name = alert.textFields[0].text;
        if (name.length > 0) {
            NSLog(@"📦 Creating package: %@", name);
            
            NSDictionary *data = @{
                @"name": name,
                @"game_version": @"1.0.0",
                @"login_enabled": @YES
            };
            
            [[APIManager sharedManager] createPackageWithData:data success:^(NSDictionary *response) {
                NSLog(@"✅ Package created: %@", response);
                [self loadPackages];
                
                if (response[@"package"]) {
                    NSDictionary *package = response[@"package"];
                    NSString *successMsg = [NSString stringWithFormat:@"Package '%@' created!\nToken: %@", package[@"name"], package[@"token"]];
                    [self showAlert:@"Success" message:successMsg];
                } else {
                    [self showAlert:@"Success" message:@"Package created successfully"];
                }
            } failure:^(NSError *error) {
                NSLog(@"❌ Failed to create package: %@", error);
                NSString *errorMsg = [NSString stringWithFormat:@"Failed to create package: %@", error.localizedDescription];
                [self showAlert:@"Error" message:errorMsg];
            }];
        }
    }]];
    
    [self presentViewController:alert animated:YES completion:nil];
}

#pragma mark - UITableView

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.packages.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellId = @"PackageCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellId];
        cell.backgroundColor = [UIColor colorWithWhite:0.1 alpha:1.0];
        cell.textLabel.textColor = [UIColor whiteColor];
        cell.detailTextLabel.textColor = [UIColor colorWithWhite:0.7 alpha:1.0];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    
    NSDictionary *package = self.packages[indexPath.row];
    cell.textLabel.text = [NSString stringWithFormat:@"📦 %@", package[@"name"]];
    NSString *token = package[@"token"];
    if (token.length > 16) {
        token = [token substringToIndex:16];
    }
    cell.detailTextLabel.text = [NSString stringWithFormat:@"Token: %@...", token];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSDictionary *package = self.packages[indexPath.row];
    NSString *packageId = package[@"id"];
    NSString *packageName = package[@"name"];
    NSString *token = package[@"token"];
    NSString *status = package[@"status"] ?: @"active";
    BOOL isActive = [status isEqualToString:@"active"];
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Package Actions" message:packageName preferredStyle:UIAlertControllerStyleActionSheet];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"📋 View Details" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        NSString *details = [NSString stringWithFormat:@"Package: %@\nToken: %@\nStatus: %@", packageName, token, status];
        [self showAlert:@"Package Details" message:details];
    }]];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"🔑 Copy Token" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        UIPasteboard.generalPasteboard.string = token;
        [self showAlert:@"Copied" message:@"Token copied to clipboard"];
    }]];
    
    if (isActive) {
        [alert addAction:[UIAlertAction actionWithTitle:@"⏸️ Deactivate" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            [self deactivatePackage:packageId];
        }]];
    } else {
        [alert addAction:[UIAlertAction actionWithTitle:@"▶️ Activate" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            [self activatePackage:packageId];
        }]];
    }
    
    [alert addAction:[UIAlertAction actionWithTitle:@"🛡️ Toggle Anti-Inject" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        [self toggleAntiInject:packageId];
    }]];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"🗑️ Delete Package" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
        [self deletePackage:packageId];
    }]];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)activatePackage:(NSString *)packageId {
    [[APIManager sharedManager] activatePackage:packageId success:^(NSDictionary *response) {
        [self loadPackages];
        [self showAlert:@"Success" message:@"Package activated"];
    } failure:^(NSError *error) {
        [self showAlert:@"Error" message:@"Failed to activate package"];
    }];
}

- (void)deactivatePackage:(NSString *)packageId {
    [[APIManager sharedManager] deactivatePackage:packageId success:^(NSDictionary *response) {
        [self loadPackages];
        [self showAlert:@"Success" message:@"Package deactivated"];
    } failure:^(NSError *error) {
        [self showAlert:@"Error" message:@"Failed to deactivate package"];
    }];
}

- (void)toggleAntiInject:(NSString *)packageId {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Anti-Inject" message:@"Enable or disable anti-inject protection?" preferredStyle:UIAlertControllerStyleAlert];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"Enable" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        [[APIManager sharedManager] toggleAntiInject:packageId enabled:YES success:^(NSDictionary *response) {
            [self showAlert:@"Success" message:@"Anti-inject enabled"];
        } failure:^(NSError *error) {
            [self showAlert:@"Error" message:@"Failed to enable anti-inject"];
        }];
    }]];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"Disable" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
        [[APIManager sharedManager] toggleAntiInject:packageId enabled:NO success:^(NSDictionary *response) {
            [self showAlert:@"Success" message:@"Anti-inject disabled"];
        } failure:^(NSError *error) {
            [self showAlert:@"Error" message:@"Failed to disable anti-inject"];
        }];
    }]];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)deletePackage:(NSString *)packageId {
    UIAlertController *confirm = [UIAlertController alertControllerWithTitle:@"Delete Package" message:@"This will delete the package and all its keys. Continue?" preferredStyle:UIAlertControllerStyleAlert];
    
    [confirm addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    [confirm addAction:[UIAlertAction actionWithTitle:@"Delete" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
        [[APIManager sharedManager] deletePackage:packageId success:^(NSDictionary *response) {
            [self loadPackages];
            [self showAlert:@"Success" message:@"Package deleted successfully"];
        } failure:^(NSError *error) {
            [self showAlert:@"Error" message:@"Failed to delete package"];
        }];
    }]];
    
    [self presentViewController:confirm animated:YES completion:nil];
}

- (void)showAlert:(NSString *)title message:(NSString *)message {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

@end
